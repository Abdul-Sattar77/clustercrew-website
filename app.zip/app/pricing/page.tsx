"use client";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { motion } from "framer-motion";

export default function Pricing() {
  const whatsappNumber = "12269726927"; // apna number yahan daalo

  const handleWhatsApp = () => {
    window.open(`https://wa.me/${whatsappNumber}`, "_blank");
  };

  return (
    <div className="bg-[#fcfcfd] min-h-screen">
      <Navbar />

      <div className="max-w-screen-2xl mx-auto px-8 pt-44 pb-32">
        
        {/* Heading */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center mb-20"
        >
          <h1 className="text-7xl font-black tracking-tighter mb-6">
            Pricing
          </h1>

          <p className="text-xl text-gray-500">
            Contact us for pricing based on your project requirements.
          </p>
        </motion.div>

        {/* CTA Card */}
        <div className="max-w-2xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-16 rounded-[40px] border border-gray-200 bg-white text-center shadow-xl"
          >
            <h3 className="text-3xl font-black mb-8">
              Contact for Pricing
            </h3>

            <button
              onClick={handleWhatsApp}
              className="w-full py-5 rounded-3xl font-black text-xl bg-[#25D366] text-white hover:shadow-lg transition-all"
            >
              Chat on WhatsApp
            </button>
          </motion.div>
        </div>
      </div>

      <Footer />
    </div>
  );
}